CREATE PROCEDURE transmaster_transport_db.getPretensionsByReqIdExt(IN `_requestIDExternal` VARCHAR(255))
  BEGIN
    SELECT * FROM pretensions WHERE requestIDExternal = _requestIDExternal;
  END;
