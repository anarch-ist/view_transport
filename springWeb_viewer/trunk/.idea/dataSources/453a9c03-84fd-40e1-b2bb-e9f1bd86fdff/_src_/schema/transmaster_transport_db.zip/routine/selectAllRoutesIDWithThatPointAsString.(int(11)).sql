CREATE FUNCTION transmaster_transport_db.selectAllRoutesIDWithThatPointAsString(`_pointID` INT)
  RETURNS TEXT
  BEGIN
    SET @result = (SELECT GROUP_CONCAT(DISTINCT routes.routeID)
                   FROM routes
                     INNER JOIN (route_points, points)
                       ON (routes.routeID = route_points.routeID AND route_points.pointID = points.pointID)
                   WHERE _pointID = points.pointID);
    RETURN @result;
  END;
