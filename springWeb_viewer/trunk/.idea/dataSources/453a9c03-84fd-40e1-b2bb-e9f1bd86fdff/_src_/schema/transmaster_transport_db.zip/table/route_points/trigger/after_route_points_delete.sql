CREATE TRIGGER transmaster_transport_db.after_route_points_delete
AFTER DELETE ON transmaster_transport_db.route_points
FOR EACH ROW
  BEGIN
    -- если в таблице route_points 2 или больше записей, то вставляем новые значения в relations_between_routePoints
    IF (SELECT count(*)
        FROM route_points
        WHERE OLD.routeID = route_points.routeID) >= 2
    THEN
      BEGIN

        SET @nextRoutePointID = (SELECT routePointID
                                 FROM route_points
                                 WHERE route_points.routeID = OLD.routeID AND route_points.sortOrder > OLD.sortOrder
                                 ORDER BY sortOrder ASC
                                 LIMIT 1);
        SET @previousRoutePointID = (SELECT routePointID
                                     FROM route_points
                                     WHERE route_points.routeID = OLD.routeID AND route_points.sortOrder < OLD.sortOrder
                                     ORDER BY sortOrder DESC
                                     LIMIT 1);
        IF (@nextRoutePointID IS NULL AND @previousRoutePointID IS NULL)
        THEN
          CALL generateLogistError('nextRoutePointID and previousRoutePointID is NULL');
        END IF;

        -- если мы удалили пункт из начала
        IF (@previousRoutePointID IS NULL)
        THEN
          DELETE FROM relations_between_route_points
          WHERE routePointIDFirst = OLD.routePointID;
        -- если мы удалили пункт с конца
        ELSEIF (@nextRoutePointID IS NULL)
          THEN
            DELETE FROM relations_between_route_points
            WHERE routePointIDFirst = OLD.routePointID OR routePointIDSecond = OLD.routePointID;
        -- если мы удалили пункт из середины
        ELSE
          BEGIN
            DELETE FROM relations_between_route_points
            WHERE routePointIDSecond = OLD.routePointID;
            UPDATE relations_between_route_points
            SET routePointIDFirst = @previousRoutePointID, timeForDistance = 0
            WHERE routePointIDFirst = OLD.routePointID;
          END;
        END IF;
      END;
    END IF;

    CALL refreshRoutePointsSequential(OLD.routeID);
  END;
