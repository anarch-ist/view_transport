CREATE TRIGGER transmaster_transport_db.before_request_delete
BEFORE DELETE ON transmaster_transport_db.requests
FOR EACH ROW
  BEGIN
    INSERT IGNORE INTO  transmaster_transport_db_archive.data_sources SELECT * FROM transmaster_transport_db.data_sources WHERE dataSourceID=OLD.dataSourceID;

    INSERT IGNORE INTO transmaster_transport_db_archive.clients SELECT * FROM transmaster_transport_db.clients WHERE clientID=OLD.clientID;

    INSERT IGNORE INTO transmaster_transport_db_archive.points SELECT * FROM transmaster_transport_db.points WHERE pointID=OLD.destinationPointID;
    INSERT IGNORE INTO transmaster_transport_db_archive.point_types SELECT * FROM transmaster_transport_db.point_types WHERE pointTypeID=(SELECT pointTypeID FROM points WHERE pointID=OLD.destinationPointID);
    INSERT IGNORE INTO transmaster_transport_db_archive.data_sources SELECT * FROM transmaster_transport_db.data_sources WHERE dataSourceID=(SELECT dataSourceID FROM points WHERE pointID=OLD.destinationPointID);

    INSERT IGNORE INTO transmaster_transport_db_archive.data_sources SELECT * FROM transmaster_transport_db.data_sources WHERE dataSourceID=(SELECT dataSourceID FROM users WHERE userID=OLD.marketAgentUserID);
    INSERT IGNORE INTO transmaster_transport_db_archive.user_roles SELECT * FROM transmaster_transport_db.user_roles WHERE userRoleID = (SELECT userRoleID FROM users WHERE userID=OLD.marketAgentUserID);
    INSERT IGNORE INTO transmaster_transport_db_archive.users SELECT * FROM transmaster_transport_db.users WHERE userID=OLD.marketAgentUserID;

    INSERT IGNORE INTO  transmaster_transport_db_archive.request_statuses SELECT * FROM transmaster_transport_db.request_statuses WHERE requestStatusID = OLD.requestStatusID;

    INSERT IGNORE INTO transmaster_transport_db_archive.data_sources SELECT * FROM transmaster_transport_db.data_sources WHERE dataSourceID = (SELECT dataSourceID FROM points WHERE pointID = OLD.warehousePointID);
    INSERT IGNORE INTO transmaster_transport_db_archive.point_types SELECT * FROM transmaster_transport_db.point_types WHERE pointTypeID = (SELECT pointTypeID FROM points WHERE pointID = OLD.warehousePointID);
    INSERT IGNORE INTO transmaster_transport_db_archive.points SELECT * FROM transmaster_transport_db.points WHERE pointID = OLD.warehousePointID;


    INSERT IGNORE INTO transmaster_transport_db_archive.route_lists SELECT * FROM transmaster_transport_db.route_lists WHERE routeListID = OLD.routeListID;

    INSERT IGNORE INTO transmaster_transport_db_archive.route_points SELECT * FROM transmaster_transport_db.route_points WHERE routePointID = OLD.lastVisitedRoutePointID;

    INSERT IGNORE INTO transmaster_transport_db_archive.user_roles SELECT * FROM transmaster_transport_db.user_roles WHERE userRoleID = (SELECT userRoleID FROM transmaster_transport_db.users WHERE userID = OLD.lastModifiedBy);
    INSERT IGNORE INTO transmaster_transport_db_archive.data_sources SELECT * FROM transmaster_transport_db.data_sources WHERE dataSourceID = (SELECT dataSourceID FROM users WHERE userID = OLD.lastModifiedBy);
    INSERT IGNORE INTO transmaster_transport_db_archive.points SELECT * FROM transmaster_transport_db.points WHERE pointID = (SELECT pointID FROM transmaster_transport_db.users WHERE userID=OLD.lastModifiedBy);
    INSERT IGNORE INTO transmaster_transport_db_archive.clients SELECT * FROM clients WHERE clientID = (SELECT clientID FROM transmaster_transport_db.users WHERE userID=OLD.lastModifiedBy);
    INSERT IGNORE INTO transmaster_transport_db_archive.users SELECT * FROM transmaster_transport_db.users WHERE userID = OLD.lastModifiedBy;


    INSERT INTO requests_history
      VALUE
      (NULL, NOW(), OLD.requestID, OLD.requestIDExternal, OLD.dataSourceID, OLD.requestNumber, OLD.requestDate,
             OLD.clientID, OLD.destinationPointID, OLD.marketAgentUserID, OLD.invoiceNumber, OLD.invoiceDate,
                                                                                             OLD.documentNumber,
                                                                                             OLD.documentDate,
                                                                                             OLD.firma, OLD.storage,
                                                                                             OLD.contactName,
                                                                                             OLD.contactPhone,
                                                                                             OLD.deliveryOption,
                                                                                             OLD.deliveryDate,
                                                                                             OLD.boxQty,
        OLD.weight, OLD.volume, OLD.goodsCost,
        OLD.lastStatusUpdated, OLD.lastModifiedBy, 'DELETED', OLD.commentForStatus, OLD.warehousePointID,
        OLD.routeListID,
        OLD.lastVisitedRoutePointID);

    INSERT INTO transmaster_transport_db_archive.requests VALUE
      (NULL, OLD.requestIDExternal, OLD.dataSourceID, OLD.requestNumber, OLD.requestDate, OLD.clientID,
             OLD.destinationPointID, OLD.marketAgentUserID, OLD.invoiceNumber, OLD.invoiceDate, OLD.documentNumber,
        OLD.documentDate, OLD.firma, OLD.storage, OLD.contactName, OLD.contactPhone, OLD.deliveryOption,
        OLD.deliveryDate, OLD.boxQty, OLD.weight, OLD.volume, OLD.goodsCost, OLD.lastStatusUpdated, OLD.lastModifiedBy,
       OLD.requestStatusID, OLD.commentForStatus, OLD.warehousePointID, OLD.routeListID, OLD.lastVisitedRoutePointID);

    DELETE FROM transmaster_transport_db.requests_history
    WHERE requestIDExternal = OLD.requestIDExternal;
    DELETE FROM transmaster_transport_db.pretensions
    WHERE requestIDExternal = OLD.requestIDExternal;
  END;
