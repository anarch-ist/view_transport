CREATE PROCEDURE transmaster_transport_db.updatePretension(IN `_pretensionId`        INT,
                                                           IN `_requestIDExternal`   VARCHAR(255),
                                                           IN `_pretensionCathegory` VARCHAR(32),
                                                           IN `_pretensionComment`   TEXT, IN `_positionNumber` TEXT,
                                                           IN `_pretensionSum`       DECIMAL(10, 2))
  BEGIN
    UPDATE pretensions
    SET pretensionCathegory = _pretensionCathegory, pretensionComment = _pretensionComment,
      positionNumber        = _positionNumber, sum = _pretensionSum
    WHERE pretensionID = _pretensionId AND requestIDExternal = _requestIDExternal;
  END;
