CREATE TRIGGER transmaster_transport_db.after_route_list_insert
AFTER INSERT ON transmaster_transport_db.route_lists
FOR EACH ROW
  INSERT INTO route_list_history
  VALUES
    (NULL, NOW(), NEW.routeListID, NEW.routeListIDExternal, NEW.dataSourceID, NEW.routeListNumber, NEW.creationDate,
           NEW.departureDate, NEW.palletsQty, NEW.forwarderId, NEW.driverID,
     NEW.driverPhoneNumber, NEW.licensePlate, NEW.status, NEW.routeID, 'CREATED');
