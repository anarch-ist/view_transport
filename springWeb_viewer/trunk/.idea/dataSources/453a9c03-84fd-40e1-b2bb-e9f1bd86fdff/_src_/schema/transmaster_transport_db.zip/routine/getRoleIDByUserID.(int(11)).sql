CREATE FUNCTION transmaster_transport_db.getRoleIDByUserID(`_userID` INT)
  RETURNS VARCHAR(32)
  BEGIN
    DECLARE result VARCHAR(32);
    SET result = (SELECT userRoleID
                  FROM users
                  WHERE userID = _userID);
    RETURN result;
  END;
