CREATE PROCEDURE transmaster_transport_db.generateLogistError(IN `_errorMessage` TEXT)
  BEGIN
    SET @message_text = concat('LOGIST ERROR: ', _errorMessage);
    SIGNAL SQLSTATE '45000'
    SET MESSAGE_TEXT = @message_text;
  END;
