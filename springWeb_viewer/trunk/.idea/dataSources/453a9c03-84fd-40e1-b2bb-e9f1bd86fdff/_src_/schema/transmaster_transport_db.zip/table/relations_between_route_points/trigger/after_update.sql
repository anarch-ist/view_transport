CREATE TRIGGER transmaster_transport_db.after_update
AFTER UPDATE ON transmaster_transport_db.relations_between_route_points
FOR EACH ROW
  BEGIN
    UPDATE mat_view_route_points_sequential
    SET mat_view_route_points_sequential.timeToNextPoint = NEW.timeForDistance
    WHERE
      mat_view_route_points_sequential.routePointID = NEW.routePointIDFirst AND
      mat_view_route_points_sequential.nextRoutePointID IS NOT NULL AND
      mat_view_route_points_sequential.nextRoutePointID = NEW.routePointIDSecond;
  END;
