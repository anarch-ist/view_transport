CREATE TRIGGER transmaster_transport_db.after_clients_update
AFTER UPDATE ON transmaster_transport_db.clients
FOR EACH ROW
  BEGIN
    IF (NEW.clientName <> OLD.clientName)
    THEN
      UPDATE mat_view_big_select
      SET clientName = NEW.clientName
      WHERE clientID = NEW.clientID;
    END IF;

    IF (NEW.INN <> OLD.INN)
    THEN
      UPDATE mat_view_big_select
      SET INN = NEW.INN
      WHERE clientID = NEW.clientID;
    END IF;
  END;
