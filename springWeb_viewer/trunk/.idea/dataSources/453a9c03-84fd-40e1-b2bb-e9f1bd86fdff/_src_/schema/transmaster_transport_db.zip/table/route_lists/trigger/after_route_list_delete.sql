CREATE TRIGGER transmaster_transport_db.after_route_list_delete
AFTER DELETE ON transmaster_transport_db.route_lists
FOR EACH ROW
  INSERT INTO route_list_history
  VALUES
    (NULL, NOW(), OLD.routeListID, OLD.routeListIDExternal, OLD.dataSourceID, OLD.routeListNumber, OLD.creationDate,
           OLD.departureDate, OLD.palletsQty, OLD.forwarderId, OLD.driverID,
     OLD.driverPhoneNumber, OLD.licensePlate, OLD.status, OLD.routeID, 'DELETED');
