CREATE PROCEDURE transmaster_transport_db.deletePretension(IN `_pretensionId` INT, IN `_requestIDExternal` VARCHAR(255))
  BEGIN
    DELETE FROM pretensions WHERE pretensionID = _pretensionId AND requestIDExternal = _requestIDExternal;
  END;
