CREATE PROCEDURE transmaster_transport_db.checkUserConstraints(IN `_userRoleID` VARCHAR(255), IN `_pointID` INT,
                                                               IN `_clientID`   INT, IN `_userIDExternal` VARCHAR(255),
                                                               IN `_login`      VARCHAR(255))
  BEGIN
    IF (_userRoleID IN ('ADMIN', 'CLIENT_MANAGER', 'MARKET_AGENT') AND _pointID IS NOT NULL)
    THEN
      CALL generateLogistError(
          CONCAT('ADMIN, CLIENT_MANAGER OR MARKET_AGENT  can't have a point. userIDExternal = ', _userIDExternal,
                 ', login = ', _login));
    END IF;

    IF (_userRoleID IN ('DISPATCHER', 'W_DISPATCHER') AND _pointID IS NULL)
    THEN
      CALL generateLogistError(
          CONCAT('DISPATCHER OR W_DISPATCHER must have a point. userIDExternal = ', _userIDExternal, ', login = ',
                 _login));
    END IF;

    IF (_userRoleID = 'CLIENT_MANAGER' AND _clientID IS NULL)
    THEN
      CALL generateLogistError(
          CONCAT('CLIENT_MANAGER must have clientID. userIDExternal = ', _userIDExternal, ', login = ', _login));
    END IF;

    IF (_userRoleID IN ('DISPATCHER', 'W_DISPATCHER', 'MARKET_AGENT', 'ADMIN') AND _clientID IS NOT NULL)
    THEN
      CALL generateLogistError(
          CONCAT('clientID must be null for userIDExternal = ', _userIDExternal, ', login = ', _login));
    END IF;
  END
;
