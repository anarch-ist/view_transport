CREATE TRIGGER transmaster_transport_db.before_route_points_insert
BEFORE INSERT ON transmaster_transport_db.route_points
FOR EACH ROW
  CALL check_route_points_constraints(NEW.routeID, NEW.sortOrder, NEW.pointID);
