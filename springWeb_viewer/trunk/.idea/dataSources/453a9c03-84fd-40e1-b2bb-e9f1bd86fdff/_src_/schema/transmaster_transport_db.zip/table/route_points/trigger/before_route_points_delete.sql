CREATE TRIGGER transmaster_transport_db.before_route_points_delete
BEFORE DELETE ON transmaster_transport_db.route_points
FOR EACH ROW
  CALL check_route_points_constraints(OLD.routeID, OLD.sortOrder, OLD.pointID);
