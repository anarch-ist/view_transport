CREATE TRIGGER transmaster_transport_db.before_route_points_update
BEFORE UPDATE ON transmaster_transport_db.route_points
FOR EACH ROW
  BEGIN
    CALL generateLogistError('updates on route_points disabled');
  END;
