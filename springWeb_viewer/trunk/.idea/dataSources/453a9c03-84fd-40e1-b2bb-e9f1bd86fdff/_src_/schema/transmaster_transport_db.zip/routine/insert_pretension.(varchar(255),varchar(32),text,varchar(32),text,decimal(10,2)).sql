CREATE PROCEDURE transmaster_transport_db.insert_pretension(IN `_requestIDExternal`        VARCHAR(255),
                                                            IN `_pretensionStatus`         VARCHAR(32),
                                                            IN `_pretensionComment`        TEXT,
                                                            IN `_pretensionCathegory`      VARCHAR(32),
                                                            IN `_pretensionPositionNumber` TEXT,
                                                            IN `_pretensionSum`            DECIMAL(10, 2))
  BEGIN
    INSERT INTO pretensions (requestIDExternal, pretensionStatus, pretensionComment, pretensionCathegory, PositionNumber, sum, dateAdded)
    VALUES (_requestIDExternal, _pretensionStatus, _pretensionComment, _pretensionCathegory, _pretensionPositionNumber,
            _pretensionSum, CURRENT_DATE);
  UPDATE requests SET requestStatusID='PRETENSION_CREATED' WHERE requestIDExternal=_requestIDExternal;
  END;
