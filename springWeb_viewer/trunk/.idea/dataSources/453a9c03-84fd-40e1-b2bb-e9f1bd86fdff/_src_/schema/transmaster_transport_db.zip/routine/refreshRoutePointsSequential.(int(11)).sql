CREATE PROCEDURE transmaster_transport_db.refreshRoutePointsSequential(IN `_routeID` INT)
  BEGIN

    DELETE FROM mat_view_route_points_sequential
    WHERE routeID = _routeID;

    INSERT INTO mat_view_route_points_sequential
      SELECT
        mainRP.routeID,
        mainRP.routePointID,
        innerRP.routePointID                           AS nextRoutePointID,
        innerRP.pointID                                AS nextPointID,
        points.pointName                               AS nextPointName,
        relations_between_route_points.timeForDistance AS timeToNextPoint
      FROM route_points mainRP
        LEFT JOIN route_points innerRP ON (
          innerRP.routeID = _routeID AND
          mainRP.routeID = _routeID AND
          innerRP.sortOrder = (SELECT innerRP2.sortOrder
                               FROM route_points innerRP2
                               WHERE (innerRP2.routeID = _routeID AND innerRP2.sortOrder > mainRP.sortOrder)
                               ORDER BY innerRP.sortOrder
                               LIMIT 1)
          )
        LEFT JOIN points ON points.pointID = innerRP.pointID
        LEFT JOIN relations_between_route_points ON (
          relations_between_route_points.routePointIDFirst = mainRP.routePointID AND
          relations_between_route_points.routePointIDSecond = innerRP.routePointID
          )
      WHERE mainRP.routeID = _routeID;

  END;
