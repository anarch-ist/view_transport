CREATE PROCEDURE transmaster_transport_db.selectTransportCompanies(IN `_startEntry` INT, IN `_length` INT,
                                                                   IN `_orderby`    VARCHAR(255),
                                                                   IN `_isDesc`     TINYINT(1), IN `_search` TEXT)
  BEGIN

    SET @searchString = CONCAT('%', _search, '%');

    SELECT SQL_CALC_FOUND_ROWS
      tc.*
    FROM transmaster_transport_db.transport_companies tc
    WHERE (
            _search = '' OR
            tc.id LIKE @searchString collate utf8_general_ci  OR
            tc.name LIKE @searchString collate utf8_general_ci OR
            tc.short_name LIKE @searchString collate utf8_general_ci OR
            tc.inn LIKE @searchString collate utf8_general_ci OR
            tc.KPP LIKE @searchString collate utf8_general_ci OR
            tc.BIK LIKE @searchString collate utf8_general_ci OR
            tc.cor_account LIKE @searchString collate utf8_general_ci OR
            tc.cur_account LIKE @searchString collate utf8_general_ci OR
            tc.bank_name LIKE @searchString collate utf8_general_ci OR
            tc.legal_address LIKE @searchString collate utf8_general_ci OR
            tc.post_address LIKE @searchString collate utf8_general_ci OR
            tc.keywords LIKE @searchString collate utf8_general_ci OR
            tc.director_fullname LIKE @searchString collate utf8_general_ci OR
            tc.chief_acc_fullname LIKE @searchString collate utf8_general_ci
          ) AND deleted = FALSE
    ORDER BY NULL,
      CASE WHEN _orderby = ''
        THEN NULL END,
      CASE WHEN _isDesc AND  _orderby = 'id'
        THEN id END ASC,
      CASE WHEN _isDesc AND  _orderby = 'name'
        THEN name END ASC,
      CASE WHEN _isDesc AND  _orderby = 'short_name'
        THEN short_name END ASC,
      CASE WHEN _isDesc AND  _orderby = 'inn'
        THEN inn END ASC,
      CASE WHEN _isDesc AND  _orderby = 'KPP'
        THEN KPP END ASC,
      CASE WHEN _isDesc AND _orderby = 'BIK'
        THEN BIK END ASC,
      CASE WHEN _isDesc AND _orderby = 'cor_account'
        THEN cor_account END ASC,
      CASE WHEN _isDesc AND _orderby = 'cur_account'
        THEN cur_account END ASC,
      CASE WHEN _isDesc AND _orderby = 'bank_name'
        THEN bank_name END ASC,
      CASE WHEN _isDesc AND _orderby = 'legal_address'
        THEN legal_address END ASC,
      CASE WHEN _isDesc AND _orderby = 'post_address'
        THEN post_address END ASC,
      CASE WHEN _isDesc AND _orderby = 'keywords'
        THEN keywords END ASC,
      CASE WHEN _isDesc AND _orderby = 'director_fullname'
        THEN director_fullname END ASC,
      CASE WHEN _isDesc AND _orderby = 'chief_acc_fullname'
        THEN chief_acc_fullname END ASC,
      CASE WHEN NOT (_isDesc) AND  _orderby = 'id'
        THEN id END DESC ,
      CASE  WHEN NOT (_isDesc) AND  _orderby = 'name'
        THEN name END DESC,
      CASE  WHEN NOT (_isDesc) AND  _orderby = 'short_name'
        THEN short_name END DESC,
      CASE  WHEN NOT (_isDesc) AND  _orderby = 'inn'
        THEN inn END DESC,
      CASE  WHEN NOT (_isDesc) AND  _orderby = 'KPP'
        THEN KPP END DESC,
      CASE  WHEN NOT (_isDesc) AND _orderby = 'BIK'
        THEN BIK END DESC,
      CASE  WHEN NOT (_isDesc) AND _orderby = 'cor_account'
        THEN cor_account END DESC,
      CASE  WHEN NOT (_isDesc) AND _orderby = 'cur_account'
        THEN cur_account END DESC,
      CASE  WHEN NOT (_isDesc) AND _orderby = 'bank_name'
        THEN bank_name END DESC,
      CASE  WHEN NOT (_isDesc) AND _orderby = 'legal_address'
        THEN legal_address END DESC,
      CASE  WHEN NOT (_isDesc) AND _orderby = 'post_address'
        THEN post_address END DESC,
      CASE  WHEN NOT (_isDesc) AND _orderby = 'keywords'
        THEN keywords END DESC,
      CASE  WHEN NOT (_isDesc) AND _orderby = 'director_fullname'
        THEN director_fullname END DESC,
      CASE  WHEN NOT (_isDesc) AND _orderby = 'chief_acc_fullname'
        THEN chief_acc_fullname END DESC
    LIMIT _startEntry, _length;

    -- filtered routes
    SELECT FOUND_ROWS() AS `totalFiltered`;

    -- total routes
    SELECT COUNT(*) AS `totalCount`
    FROM transport_companies
    WHERE deleted = FALSE;

  END;
