CREATE TRIGGER transmaster_transport_db.check_users_constraints_insert
BEFORE INSERT ON transmaster_transport_db.users
FOR EACH ROW
  CALL checkUserConstraints(NEW.userRoleID, NEW.pointID, NEW.clientID, NEW.userIDExternal, NEW.login);
