CREATE TRIGGER transmaster_transport_db.after_routes_update
AFTER UPDATE ON transmaster_transport_db.routes
FOR EACH ROW
  IF (NEW.routeName <> OLD.routeName)
  THEN
    UPDATE mat_view_big_select
    SET routeName = NEW.routeName
    WHERE routeID = NEW.routeID;
  END IF;
