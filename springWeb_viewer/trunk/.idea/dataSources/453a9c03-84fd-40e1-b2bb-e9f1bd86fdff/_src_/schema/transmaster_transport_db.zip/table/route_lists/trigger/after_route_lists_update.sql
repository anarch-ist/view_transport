CREATE TRIGGER transmaster_transport_db.after_route_lists_update
AFTER UPDATE ON transmaster_transport_db.route_lists
FOR EACH ROW
  BEGIN

    INSERT INTO route_list_history
    VALUES
      (NULL, NOW(), NEW.routeListID, NEW.routeListIDExternal, NEW.dataSourceID, NEW.routeListNumber, NEW.creationDate,
             NEW.departureDate, NEW.palletsQty, NEW.forwarderId, NEW.driverID,
       NEW.driverPhoneNumber, NEW.licensePlate, NEW.status, NEW.routeID, 'UPDATED');

    -- синхронизация при изменении маршрутного листа routeListNumber, licencePlate, palletsQty
    IF (NEW.routeListNumber <> OLD.routeListNumber)
    THEN
      UPDATE mat_view_big_select
      SET routeListNumber = NEW.routeListNumber
      WHERE routeListID = NEW.routeListID;
    END IF;

    IF (NEW.licensePlate <> OLD.licensePlate)
    THEN
      UPDATE mat_view_big_select
      SET licensePlate = NEW.licensePlate
      WHERE routeListID = NEW.routeListID;
    END IF;

    IF (NEW.palletsQty <> OLD.palletsQty)
    THEN
      UPDATE mat_view_big_select
      SET palletsQty = NEW.palletsQty
      WHERE routeListID = NEW.routeListID;
    END IF;
  END;
