CREATE TRIGGER transmaster_transport_db.after_request_update
AFTER UPDATE ON transmaster_transport_db.requests
FOR EACH ROW
  BEGIN
    INSERT INTO transmaster_transport_db.requests_history
      VALUE
      (NULL, NOW(), NEW.requestID, NEW.requestIDExternal, NEW.dataSourceID, NEW.requestNumber, NEW.requestDate,
             NEW.clientID, NEW.destinationPointID, NEW.marketAgentUserID, NEW.invoiceNumber, NEW.invoiceDate,
                                                                                             NEW.documentNumber,
                                                                                             NEW.documentDate,
                                                                                             NEW.firma, NEW.storage,
                                                                                             NEW.contactName,
                                                                                             NEW.contactPhone,
                                                                                             NEW.deliveryOption,
                                                                                             NEW.deliveryDate,
                                                                                             NEW.boxQty, NEW.weight,
                                                                                                         NEW.volume,
                                                                                                         NEW.goodsCost,
                                                                                                         NEW.lastStatusUpdated,
                                                                                                         NEW.lastModifiedBy,
                                                                                                         NEW.requestStatusID,
                                                                                                         NEW.commentForStatus,
                                                                                                         NEW.warehousePointID,
                                                                                                         NEW.routeListID,
                                                                                                         NEW.lastVisitedRoutePointID


      );

    #     UPDATE mat_view_big_select SET
    #       requestIDExternal = NEW.requestIDExternal, requestNumber = NEW.requestNumber, requestDate = NEW.requestDate,
    #       invoiceNumber = NEW.invoiceNumber, invoiceDate = NEW.invoiceDate, documentNumber = NEW.documentNumber,
    #       documentDate = NEW.documentDate, firma = NEW.firma, storage = NEW.storage, boxQty = NEW.boxQty,
    #       requestStatusID = NEW.requestStatusID, commentForStatus = NEW.commentForStatus, routeListID = NEW.routeListID
    #       WHERE mat_view_big_select.requestID = NEW.requestID;

    -- расчет времени прибытия заявки в следующий пункт маршрута
    IF (NEW.requestStatusID = 'DEPARTURE')
    THEN
      BEGIN
        SET @timeToNextPoint = (SELECT timeToNextPoint
                                FROM mat_view_route_points_sequential
                                WHERE routePointID = NEW.lastVisitedRoutePointID);
        SET @arrivalTimeToNextPoint = TIMESTAMPADD(MINUTE, @timeToNextPoint, NEW.lastStatusUpdated);

        INSERT INTO mat_view_arrival_time_for_request VALUE (NEW.requestID, @arrivalTimeToNextPoint)
        ON DUPLICATE KEY UPDATE
          arrivalTimeToNextRoutePoint = VALUES(arrivalTimeToNextRoutePoint);
      END;
    END IF;

    CALL singleInsertOrUpdateOnMatViewBigSelect(NEW.requestID);
  END;
