CREATE FUNCTION transmaster_transport_db.generateOrderByPart(`_orderby` VARCHAR(255), `_isDesc` TINYINT(1))
  RETURNS VARCHAR(255)
  BEGIN

    IF (_orderby = '')
    THEN RETURN ' ORDER BY requestDate ASC';
    END IF;

    IF (_isDesc)
    THEN
      RETURN CONCAT(' ORDER BY ', _orderby, ' DESC');
    ELSE
      RETURN CONCAT(' ORDER BY ', _orderby);
    END IF;

  END;
