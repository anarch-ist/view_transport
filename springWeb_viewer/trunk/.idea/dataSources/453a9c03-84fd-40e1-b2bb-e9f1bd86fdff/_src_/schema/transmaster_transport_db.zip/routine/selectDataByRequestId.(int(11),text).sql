CREATE PROCEDURE transmaster_transport_db.selectDataByRequestId(IN `_userID` INT, IN requestIDExternal TEXT)
  BEGIN

    SET @userRoleID = getRoleIDByUserID(_userID);

    SET @isAdmin = FALSE;
    SET @isMarketAgent = FALSE;
    SET @isClientManager = FALSE;
    SET @isDispatcherOrWDispatcher = FALSE;

    IF (@userRoleID = 'ADMIN') THEN
      SET @isAdmin = TRUE;
    ELSEIF (@userRoleID = 'MARKET_AGENT') THEN
      SET @isMarketAgent = TRUE;
    ELSEIF (@userRoleID = 'CLIENT_MANAGER') THEN
      SET @isClientManager = TRUE;
    ELSEIF (@userRoleID = 'DISPATCHER' OR @userRoleID = 'W_DISPATCHER') THEN
      SET @isDispatcherOrWDispatcher = TRUE;
    END IF;

    IF (@isClientManager) THEN
      SET @clientID = getClientIDByUserID(_userID);
    END IF;

    IF (@isDispatcherOrWDispatcher) THEN
      SET @userPointID = getPointIDByUserID(_userID);
      SET @allRoutesWithUserPointID = selectAllRoutesIDWithThatPointAsString(@userPointID);
    END IF;

    -- 1) если у пользователя роль админ, то показываем все записи из БД
    -- 2) если статус пользователя - агент, то показываем ему только те заявки которые он породил.
    -- 3) если пользователь находится на складе, на котором формируется заявка, то показываем ему эти записи
    -- 4) если маршрут накладной проходит через пользователя, то показываем ему эти записи
    SET @columnsPart =
    '
    SELECT SQL_CALC_FOUND_ROWS
      requestIDExternal,
      requestNumber,
      requestDate,
      invoiceNumber,
      invoiceDate,
      documentNumber,
      documentDate,
      firma,
      storage,
      boxQty,
      requestStatusID,
      commentForStatus,
      requestStatusRusName,
      clientIDExternal,
      INN,
      clientName,
      marketAgentUserName,
      driverUserName,
      deliveryPointName,
      warehousePointName,
      lastVisitedPointName,
      nextPointName,
      routeListNumber,
      licensePlate,
      palletsQty,
      routeListID,
      routeName,
      arrivalTimeToNextRoutePoint
    FROM mat_view_big_select
    ';

    SET @wherePart = '';

    IF @isAdmin THEN
      SET @wherePart = CONCAT('WHERE (requestIDExternal = "', requestIDExternal,'")');
    ELSEIF @isMarketAgent THEN
      SET @wherePart = CONCAT('WHERE (marketAgentUserID = "', _userID,'") AND (requestIDExternal = "', requestIDExternal,'")');
    ELSEIF @isClientManager THEN
      SET @wherePart = CONCAT('WHERE (clientID = ', @clientID,') AND  (requestIDExternal = "', requestIDExternal,'")');
    ELSEIF @isDispatcherOrWDispatcher THEN
      SET @wherePart = CONCAT('WHERE (routeID IN (', @allRoutesWithUserPointID,')) AND  (requestIDExternal = "', requestIDExternal,'")');
    END IF;

    SET @limitPart = ' LIMIT 1';

    SET @sqlString = CONCAT(@columnsPart, @wherePart, @limitPart);

    PREPARE getDataStm FROM @sqlString;

    EXECUTE getDataStm;
    DEALLOCATE PREPARE getDataStm;


  END;
