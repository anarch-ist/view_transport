CREATE PROCEDURE transmaster_transport_db.selectCompanies()
  BEGIN
    SELECT * FROM transport_companies;
  END;
