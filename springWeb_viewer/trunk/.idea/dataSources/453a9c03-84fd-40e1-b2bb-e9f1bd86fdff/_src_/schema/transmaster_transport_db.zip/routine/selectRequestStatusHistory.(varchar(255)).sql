CREATE PROCEDURE transmaster_transport_db.selectRequestStatusHistory(IN `_requestIDExternal` VARCHAR(255))
  BEGIN
    SELECT
      MAX(requests_history.lastStatusUpdated) AS timeMarkWhenRequestWasChanged,
      requests_history.boxQty                 AS boxQty,
      request_statuses.requestStatusRusName   AS requestStatusRusName,
      points.pointName                        AS pointWhereStatusWasChanged,
      users.userName                          AS userNameThatChangedStatus,
      route_lists.routeListIDExternal         AS routeListIDExternal,
      route_lists.routeListNumber             AS routeListNumber

    FROM requests_history
      INNER JOIN (request_statuses)
        ON (
        requests_history.requestStatusID = request_statuses.requestStatusID
        )
      LEFT JOIN (points, route_points) ON (
        requests_history.lastVisitedRoutePointID = route_points.routePointID AND
        route_points.pointID = points.pointID
        )
      LEFT JOIN (users) ON (
        requests_history.lastModifiedBy = users.userID
        )
      LEFT JOIN (route_lists) ON (
        requests_history.routeListID = route_lists.routeListID
        )
    WHERE requests_history.requestIDExternal = _requestIDExternal
          AND requests_history.lastStatusUpdated IS NOT NULL
          AND requests_history.lastStatusUpdated != '0000-00-00 00:00:00'
    GROUP BY requests_history.requestStatusID
    ORDER BY timeMarkWhenRequestWasChanged;
  END;
