CREATE TRIGGER transmaster_transport_db.before_pretension_delete
BEFORE DELETE ON transmaster_transport_db.pretensions
FOR EACH ROW
  BEGIN
    INSERT INTO transmaster_transport_db_archive.pretensions VALUE (0,OLD.pretensionComment,OLD.requestIDExternal,OLD.pretensionStatus,OLD.pretensionCathegory,OLD.sum,OLD.positionNumber,OLD.dateAdded);
  END;
