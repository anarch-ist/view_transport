CREATE TRIGGER transmaster_transport_db.before_requestsHistory_delete
BEFORE DELETE ON transmaster_transport_db.requests_history
FOR EACH ROW
  BEGIN
    INSERT INTO transmaster_transport_db_archive.requests_history VALUE (0,OLD.autoTimeMark,OLD.requestID,OLD.requestIDExternal,OLD.dataSourceID,OLD.requestNumber,OLD.requestDate,OLD.clientID,OLD.destinationPointID,OLD.marketAgentUserID,OLD.invoiceNumber,OLD.invoiceDate,OLD.documentNumber,OLD.documentDate,OLD.firma,OLD.storage,OLD.contactName,OLD.contactPhone,OLD.deliveryOption,OLD.deliveryDate,OLD.boxQty,OLD.weight,OLD.volume,OLD.goodsCost,OLD.lastStatusUpdated,OLD.lastModifiedBy,OLD.requestStatusID,OLD.commentForStatus,OLD.warehousePointID,OLD.routeListID,OLD.lastVisitedRoutePointID);
  END;
