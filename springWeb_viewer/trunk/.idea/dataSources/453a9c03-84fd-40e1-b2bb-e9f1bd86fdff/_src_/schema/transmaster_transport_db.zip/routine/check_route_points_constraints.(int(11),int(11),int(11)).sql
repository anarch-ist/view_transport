CREATE PROCEDURE transmaster_transport_db.check_route_points_constraints(IN `_routeID` INT, IN `_sortOrder` INT,
                                                                         IN `_pointID` INT)
  BEGIN
    -- получить пункт сверху и снизу
    SET @nextPointID = (SELECT pointID
                        FROM route_points
                        WHERE route_points.routeID = _routeID AND route_points.sortOrder > _sortOrder
                        ORDER BY sortOrder ASC
                        LIMIT 1);
    SET @previousPointID = (SELECT pointID
                            FROM route_points
                            WHERE route_points.routeID = _routeID AND route_points.sortOrder < _sortOrder
                            ORDER BY sortOrder DESC
                            LIMIT 1);
    IF ((@nextPointID IS NOT NULL AND @previousPointID IS NOT NULL AND
         ((_pointID = @nextPointID) OR (_pointID = @previousPointID))) OR
        (@nextPointID IS NULL AND (_pointID = @previousPointID)) OR
        (@previousPointID IS NULL AND (_pointID = @nextPointID)))
    THEN
      CALL generateLogistError('can't add new route point because same neighbors');
    END IF;
  END
;
