CREATE TRIGGER transmaster_transport_db.after_route_points_insert
AFTER INSERT ON transmaster_transport_db.route_points
FOR EACH ROW
  BEGIN
    -- если в таблице route_points 2 или больше записей, то вставляем новые значения в relations_between_routePoints
    IF (SELECT count(*)
        FROM route_points
        WHERE NEW.routeID = route_points.routeID) > 1
    THEN
      BEGIN

        SET @nextRoutePointID = (SELECT routePointID
                                 FROM route_points
                                 WHERE route_points.routeID = NEW.routeID AND route_points.sortOrder > NEW.sortOrder
                                 ORDER BY sortOrder ASC
                                 LIMIT 1);
        SET @previousRoutePointID = (SELECT routePointID
                                     FROM route_points
                                     WHERE route_points.routeID = NEW.routeID AND route_points.sortOrder < NEW.sortOrder
                                     ORDER BY sortOrder DESC
                                     LIMIT 1);
        IF (@nextRoutePointID IS NULL AND @previousRoutePointID IS NULL)
        THEN
          CALL generateLogistError('nextRoutePointID and previousRoutePointID is NULL');
        END IF;

        -- если мы добавили новый пункт в начало
        IF (@previousRoutePointID IS NULL)
        THEN
          INSERT INTO relations_between_route_points VALUE (NEW.routePointID, @nextRoutePointID, 0);
        -- если мы добавили новый пункт в конец
        ELSEIF (@nextRoutePointID IS NULL)
          THEN
            INSERT INTO relations_between_route_points VALUE (@previousRoutePointID, NEW.routePointID, 0);
        -- если мы добавили новый пункт в середину
        ELSE
          BEGIN
            UPDATE relations_between_route_points
            SET routePointIDSecond = NEW.routePointID, timeForDistance = 0
            WHERE routePointIDFirst = @previousRoutePointID AND routePointIDSecond = @nextRoutePointID;
            INSERT INTO relations_between_route_points VALUE (NEW.routePointID, @nextRoutePointID, 0);
          END;
        END IF;

        CALL refreshRoutePointsSequential(NEW.routeID);
      END;
    END IF;
  END;
