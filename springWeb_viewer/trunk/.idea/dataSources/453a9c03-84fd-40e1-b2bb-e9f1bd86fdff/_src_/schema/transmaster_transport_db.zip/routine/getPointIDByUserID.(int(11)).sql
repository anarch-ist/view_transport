CREATE FUNCTION transmaster_transport_db.getPointIDByUserID(`_userID` INT)
  RETURNS INT
  BEGIN
    DECLARE result INTEGER;
    SET result = (SELECT pointID
                  FROM users
                  WHERE userID = _userID);
    RETURN result;
  END;
