CREATE VIEW transmaster_transport_db.all_users AS
  SELECT
    `u`.`userID`          AS `userId`,
    `u`.`login`           AS `login`,
    `u`.`userName`        AS `userName`,
    `u`.`position`        AS `position`,
    `u`.`phoneNumber`     AS `phoneNumber`,
    `u`.`email`           AS `email`,
    'dummy'               AS `password`,
    `p`.`pointName`       AS `pointName`,
    `r`.`userRoleRusName` AS `userRoleRusName`,
    `c`.`clientID`        AS `clientID`
  FROM (((`transmaster_transport_db`.`users` `u` LEFT JOIN `transmaster_transport_db`.`points` `p`
      ON ((`p`.`pointID` = `u`.`pointID`))) LEFT JOIN `transmaster_transport_db`.`clients` `c`
      ON ((`c`.`clientID` = `u`.`clientID`))) JOIN `transmaster_transport_db`.`user_roles` `r`
      ON ((`r`.`userRoleID` = `u`.`userRoleID`)));
