CREATE TRIGGER transmaster_transport_db.after_request_insert
AFTER INSERT ON transmaster_transport_db.requests
FOR EACH ROW
  BEGIN
    INSERT INTO requests_history
      VALUE
      (NULL, NOW(), NEW.requestID, NEW.requestIDExternal, NEW.dataSourceID, NEW.requestNumber, NEW.requestDate,
             NEW.clientID, NEW.destinationPointID, NEW.marketAgentUserID, NEW.invoiceNumber, NEW.invoiceDate,
                                                                                             NEW.documentNumber,
                                                                                             NEW.documentDate,
                                                                                             NEW.firma, NEW.storage,
                                                                                             NEW.contactName,
                                                                                             NEW.contactPhone,
                                                                                             NEW.deliveryOption,
                                                                                             NEW.deliveryDate,
                                                                                             NEW.boxQty, NEW.weight,
                                                                                                         NEW.volume,
                                                                                                         NEW.goodsCost,
                                                                                                         NEW.lastStatusUpdated,
                                                                                                         NEW.lastModifiedBy,
                                                                                                         'CREATED',
                                                                                                         NEW.commentForStatus,
                                                                                                         NEW.warehousePointID,
                                                                                                         NEW.routeListID,
                                                                                                         NEW.lastVisitedRoutePointID);

    CALL singleInsertOrUpdateOnMatViewBigSelect(NEW.requestID);
  END;
