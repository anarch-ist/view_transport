CREATE TRIGGER transmaster_transport_db.after_points_update
AFTER UPDATE ON transmaster_transport_db.points
FOR EACH ROW
  IF (NEW.pointName <> OLD.pointName)
  THEN BEGIN
    UPDATE mat_view_big_select
    SET deliveryPointName = NEW.pointName
    WHERE deliveryPointID = NEW.pointID;

    UPDATE mat_view_big_select
    SET warehousePointName = NEW.pointName
    WHERE warehousePointID = NEW.pointID;

    UPDATE mat_view_big_select
    SET lastVisitedPointName = NEW.pointName
    WHERE lastVisitedPointID = NEW.pointID;

    UPDATE mat_view_big_select
    SET nextPointName = NEW.pointName
    WHERE nextPointID = NEW.pointID;
  END;
  END IF;
