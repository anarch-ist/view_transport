CREATE PROCEDURE transmaster_transport_db.selectDrivers(IN `_startEntry` INT, IN `_length` INT,
                                                        IN `_orderby`    VARCHAR(255), IN `_isDesc` TINYINT(1),
                                                        IN `_search`     TEXT)
  BEGIN

    SET @searchString = CONCAT('%', _search, '%');

    SELECT SQL_CALC_FOUND_ROWS *
    FROM transmaster_transport_db.drivers
    WHERE (_search = '' OR
           id LIKE @searchString collate utf8_general_ci OR
           vehicle_id LIKE @searchString collate utf8_general_ci OR
           transport_company_id LIKE @searchString collate utf8_general_ci OR
           full_name LIKE @searchString collate utf8_general_ci OR
           passport LIKE @searchString collate utf8_general_ci OR
           phone LIKE @searchString collate utf8_general_ci OR
           license LIKE @searchString collate utf8_general_ci) AND deleted = FALSE
    ORDER BY NULL,
      CASE WHEN _orderby = ''
        THEN NULL END,
      CASE WHEN _isDesc AND  _orderby = 'id'
        THEN id END ASC,
      CASE WHEN _isDesc AND  _orderby = 'vehicle_id'
        THEN vehicle_id END ASC,
      CASE WHEN _isDesc AND  _orderby = 'transport_company_id'
        THEN transport_company_id END ASC,
      CASE WHEN _isDesc AND  _orderby = 'full_name'
        THEN full_name END ASC,
      CASE WHEN _isDesc AND  _orderby = 'passport'
        THEN passport END ASC,
      CASE WHEN _isDesc AND _orderby = 'phone'
        THEN phone END ASC,
      CASE WHEN _isDesc AND _orderby = 'license'
        THEN license END ASC,
      CASE WHEN NOT (_isDesc) AND  _orderby = 'id'
        THEN id END DESC,
      CASE WHEN NOT (_isDesc) AND  _orderby = 'vehicle_id'
        THEN vehicle_id END DESC,
      CASE WHEN NOT (_isDesc) AND  _orderby = 'transport_company_id'
        THEN transport_company_id END DESC,
      CASE WHEN NOT (_isDesc) AND  _orderby = 'full_name'
        THEN full_name END DESC,
      CASE WHEN NOT (_isDesc) AND  _orderby = 'passport'
        THEN passport END DESC,
      CASE WHEN NOT (_isDesc) AND  _orderby = 'phone'
        THEN phone END DESC,
      CASE WHEN NOT (_isDesc) AND _orderby = 'license'
        THEN license END DESC
    LIMIT _startEntry, _length;

    -- filtered routes
    SELECT FOUND_ROWS() AS `totalFiltered`;

    -- total routes
    SELECT COUNT(*) AS `totalCount`
    FROM drivers
    WHERE deleted = FALSE;

  END;
