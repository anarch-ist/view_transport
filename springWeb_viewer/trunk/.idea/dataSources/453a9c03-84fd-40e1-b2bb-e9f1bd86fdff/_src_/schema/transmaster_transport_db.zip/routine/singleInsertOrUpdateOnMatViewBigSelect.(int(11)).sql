CREATE PROCEDURE transmaster_transport_db.singleInsertOrUpdateOnMatViewBigSelect(IN `_requestID` INT)
  BEGIN
    INSERT INTO mat_view_big_select
      SELECT
        _requestID                    AS requestID,
        requests.requestIDExternal,
        requests.requestNumber,
        requests.requestDate,
        requests.invoiceNumber,
        requests.invoiceDate,
        requests.documentNumber,
        requests.documentDate,
        requests.firma,
        requests.storage,
        requests.boxQty,
        requests.requestStatusID,
        requests.commentForStatus,
        request_statuses.requestStatusRusName,
        clients.clientID,
        clients.clientIDExternal,
        clients.INN,
        clients.clientName,
        market_agent_users.userID     AS marketAgentUserID,
        market_agent_users.userName   AS marketAgentUserName,
        driver_users.userID           AS driverUserID,
        driver_users.userName         AS driverUserName,
        delivery_points.pointID       AS deliveryPointID,
        delivery_points.pointName     AS deliveryPointName,
        w_points.pointID              AS warehousePointID,
        w_points.pointName            AS warehousePointName,
        last_visited_points.pointID   AS lastVisitedPointID,
        last_visited_points.pointName AS lastVisitedPointName,
        mat_view_route_points_sequential.nextPointID,
        mat_view_route_points_sequential.nextPointName,
        route_lists.routeListNumber,
        route_lists.licensePlate,
        route_lists.palletsQty,
        route_lists.routeListID,
        routes.routeID,
        routes.routeName,
        mat_view_arrival_time_for_request.arrivalTimeToNextRoutePoint

      FROM requests
        INNER JOIN (request_statuses) USING (requestStatusID)
        INNER JOIN (clients) USING (clientID)
        INNER JOIN (users AS market_agent_users) ON (requests.marketAgentUserID = market_agent_users.userID)
        LEFT JOIN (route_lists) USING (routeListID)
        LEFT JOIN (users AS driver_users) ON (route_lists.driverID = driver_users.userID)
        LEFT JOIN (routes) ON (route_lists.routeID = routes.routeID)
        LEFT JOIN (route_points AS last_visited_route_points)
          ON (requests.lastVisitedRoutePointID = last_visited_route_points.routePointID)
        LEFT JOIN (mat_view_route_points_sequential)
          ON (requests.lastVisitedRoutePointID = mat_view_route_points_sequential.routePointID)
        LEFT JOIN (points AS delivery_points) ON (requests.destinationPointID = delivery_points.pointID)
        LEFT JOIN (points AS w_points) ON (requests.warehousePointID = w_points.pointID)
        LEFT JOIN (points AS last_visited_points) ON (last_visited_route_points.pointID = last_visited_points.pointID)
        LEFT JOIN (mat_view_arrival_time_for_request)
          ON (requests.requestID = mat_view_arrival_time_for_request.requestID)
      WHERE requests.requestID = _requestID

    ON DUPLICATE KEY UPDATE
      requestIDExternal           = VALUES(requestIDExternal),
      requestNumber               = VALUES(requestNumber),
      requestDate                 = VALUES(requestDate),
      invoiceNumber               = VALUES(invoiceNumber),
      invoiceDate                 = VALUES(invoiceDate),
      documentNumber              = VALUES(documentNumber),
      documentDate                = VALUES(documentDate),
      firma                       = VALUES(firma),
      storage                     = VALUES(storage),
      boxQty                      = VALUES(boxQty),
      requestStatusID             = VALUES(requestStatusID),
      commentForStatus            = VALUES(commentForStatus),
      requestStatusRusName        = VALUES(requestStatusRusName),
      clientID                    = VALUES(clientID),
      clientIDExternal            = VALUES(clientIDExternal),
      INN                         = VALUES(INN),
      clientName                  = VALUES(clientName),
      marketAgentUserID           = VALUES(marketAgentUserID),
      marketAgentUserName         = VALUES(marketAgentUserName),
      driverUserID                = VALUES(driverUserID),
      driverUserName              = VALUES(driverUserName),
      deliveryPointID             = VALUES(deliveryPointID),
      deliveryPointName           = VALUES(deliveryPointName),
      warehousePointID            = VALUES(warehousePointID),
      warehousePointName          = VALUES(warehousePointName),
      lastVisitedPointID          = VALUES(lastVisitedPointID),
      lastVisitedPointName        = VALUES(lastVisitedPointName),
      nextPointID                 = VALUES(nextPointID),
      nextPointName               = VALUES(nextPointName),
      routeListNumber             = VALUES(routeListNumber),
      licensePlate                = VALUES(licensePlate),
      palletsQty                  = VALUES(palletsQty),
      routeListID                 = VALUES(routeListID),
      routeID                     = VALUES(routeID),
      routeName                   = VALUES(routeName),
      arrivalTimeToNextRoutePoint = VALUES(arrivalTimeToNextRoutePoint);
  END;
